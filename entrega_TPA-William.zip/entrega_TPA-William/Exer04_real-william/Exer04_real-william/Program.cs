﻿using System;

class Program
{
    static void Main()
    {
        int inicial, limite;
        int peidante = 0;

        Console.Write("Digite o primeiro número: ");
        inicial = int.Parse(Console.ReadLine());

        Console.Write("Digite o segundo número: ");
        limite = int.Parse(Console.ReadLine());

        int inicio, fim;
        if (inicial < limite)
        {
            inicio = inicial;
            fim = limite;
        }
        else
        {
            inicio = limite;
            fim = inicial;
        }
        for (int i = inicio; i <= fim; i++)
        {
            if (i % 2 != 0)
            {
                peidante++;
            }
        }

        Console.WriteLine("numeros impares existentes aq: " + peidante);
    }
}
