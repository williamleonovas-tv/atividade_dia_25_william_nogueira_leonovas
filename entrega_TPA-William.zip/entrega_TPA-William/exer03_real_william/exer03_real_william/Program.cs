﻿using static System.Runtime.InteropServices.JavaScript.JSType;

namespace MyApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int inicio;
            inicio = int.Parse(Console.ReadLine());
            for (int multiplicação = 0; multiplicação <= 10; multiplicação++)
            {
                {
                    Console.WriteLine(inicio + " x " + multiplicação + " = " + (inicio * multiplicação));
                }
            }
        }
    }
}