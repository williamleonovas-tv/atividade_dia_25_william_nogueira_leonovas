﻿using System;
using System.ComponentModel.Design;

class Program
{
    static void Main()
    {
        int inicial, limite = 0;

        for (int i = 1; i <= 15; i++)
        {
            Console.Write("Digite seu" + i + " numero");
            inicial = int.Parse(Console.ReadLine());



            if (i == 1)
            {
                limite = inicial;
            }
            else if (inicial > limite)
            {

                limite = inicial;
            }
        }

        Console.WriteLine("O numero mais maior de grande foi: " + limite);
    }
}