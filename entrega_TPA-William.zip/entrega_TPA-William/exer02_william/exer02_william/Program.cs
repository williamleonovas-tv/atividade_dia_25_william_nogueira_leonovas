﻿using System;

class Program
{
    static void Main(string[] args)
    {
        int inicio;
        Console.WriteLine("Escolha seu numero inicial");
        inicio = int.Parse(Console.ReadLine());
        int limite;
        Console.WriteLine("Escolha um limite para o numero");
        limite = int.Parse(Console.ReadLine());
        int inicial, fim;
        if (inicio > limite)

        {
            inicial = inicio;
            fim = limite;
        }
        else
        {
            inicial = limite;
            fim = inicio;
        }

        for (int i = inicial; i >= fim; i--)
        {
            if (i % 2 != 0)
            {
                Console.WriteLine(i);
            }
        }
    }
}


