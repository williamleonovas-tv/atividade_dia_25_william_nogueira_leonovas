﻿namespace MyApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int inicio;
            inicio = 11;
            int limite;
            limite = 250;
            while (inicio < limite)
            {
                if (inicio % 2 == 0)
                {
                    Console.WriteLine("{0}", inicio);
                }
                inicio++;
            }
        }
    }
}